import React, { useState } from 'react';
import { X, Heart, MessageCircle, Send, ShoppingBag, Truck, ShieldCheck, Bookmark } from 'lucide-react';
import { Product } from '../types';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

const ProductModal: React.FC<ProductModalProps> = ({ product, onClose, onAddToCart }) => {
  const [selectedImage, setSelectedImage] = useState(0);

  if (!product) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-surface w-full max-w-4xl max-h-[90vh] rounded-xl overflow-hidden flex flex-col md:flex-row relative border border-secondary shadow-2xl">
        <button 
            onClick={onClose}
            className="absolute top-4 right-4 z-10 p-1 bg-black/50 rounded-full text-white hover:bg-black/70"
        >
            <X size={20} />
        </button>

        {/* Left Side: Images */}
        <div className="w-full md:w-1/2 bg-black flex flex-col justify-center items-center relative h-[40vh] md:h-auto">
             <img 
                src={product.images[selectedImage]} 
                alt={product.name}
                className="w-full h-full object-contain" 
             />
             <div className="absolute bottom-4 flex gap-2 overflow-x-auto px-4 w-full justify-center">
                 {product.images.map((img, idx) => (
                     <button 
                        key={idx}
                        onClick={() => setSelectedImage(idx)}
                        className={`w-12 h-12 rounded-md overflow-hidden border-2 transition ${idx === selectedImage ? 'border-primary' : 'border-transparent opacity-50'}`}
                     >
                         <img src={img} className="w-full h-full object-cover" />
                     </button>
                 ))}
             </div>
        </div>

        {/* Right Side: Details */}
        <div className="w-full md:w-1/2 flex flex-col h-[50vh] md:h-auto">
            {/* Header */}
            <div className="p-4 border-b border-secondary flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center text-white font-bold">D</div>
                <div>
                    <h3 className="font-bold text-text">Dsabry</h3>
                    <p className="text-xs text-muted">منتجات أصلية 100%</p>
                </div>
                <button className="mr-auto text-primary font-semibold text-sm">متابعة</button>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                <h2 className="text-2xl font-bold mb-2">{product.name}</h2>
                <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-2xl font-bold text-primary">{product.price} ج.م</span>
                    {product.stock < 5 && <span className="text-xs text-red-500 font-bold px-2 py-0.5 bg-red-500/10 rounded">متبقي {product.stock} قطع فقط</span>}
                </div>

                <div className="prose prose-invert prose-sm mb-6 text-muted">
                    <p>{product.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-6">
                    <div className="bg-background p-3 rounded-lg border border-secondary flex items-center gap-2">
                        <Truck size={20} className="text-muted" />
                        <div className="text-xs">
                            <p className="font-semibold">شحن سريع</p>
                            <p className="text-muted">خلال 2-3 أيام عمل</p>
                        </div>
                    </div>
                    <div className="bg-background p-3 rounded-lg border border-secondary flex items-center gap-2">
                        <ShieldCheck size={20} className="text-muted" />
                        <div className="text-xs">
                            <p className="font-semibold">ضمان الجودة</p>
                            <p className="text-muted">استرجاع مجاني 14 يوم</p>
                        </div>
                    </div>
                </div>

                {/* Simulated Comments */}
                <div className="space-y-4">
                    <h4 className="font-bold text-sm text-muted border-b border-secondary pb-2">التعليقات</h4>
                    <div className="flex gap-2">
                        <div className="w-8 h-8 rounded-full bg-gray-700 flex-shrink-0" />
                        <div>
                            <p className="text-sm font-semibold">أحمد محمد <span className="text-xs font-normal text-muted">منذ ساعتين</span></p>
                            <p className="text-sm">منتج رائع جداً وسرعة في التوصيل! شكراً لكم</p>
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <div className="w-8 h-8 rounded-full bg-gray-600 flex-shrink-0" />
                        <div>
                            <p className="text-sm font-semibold">سارة علي <span className="text-xs font-normal text-muted">منذ 5 ساعات</span></p>
                            <p className="text-sm">هل متوفر ألوان أخرى؟</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Footer Actions */}
            <div className="p-4 border-t border-secondary bg-surface">
                <div className="flex items-center justify-between mb-4">
                     <div className="flex gap-4">
                         <Heart size={24} className="hover:text-danger cursor-pointer transition" />
                         <MessageCircle size={24} className="hover:text-primary cursor-pointer transition" />
                         <Send size={24} className="hover:text-primary cursor-pointer transition -rotate-45 mb-1" />
                     </div>
                     <Bookmark size={24} className="hover:text-primary cursor-pointer transition" />
                </div>
                
                <button 
                    onClick={() => onAddToCart(product)}
                    className="w-full bg-primary hover:bg-blue-600 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95"
                >
                    <ShoppingBag size={20} />
                    إضافة للسلة
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ProductModal;