
import React from 'react';
import { Product } from '../types';
import { AlertTriangle, Package, TrendingUp } from 'lucide-react';

interface AdminDashboardProps {
  products: Product[];
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ products }) => {
  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">لوحة تحكم التاجر</h2>
          <span className="text-xs bg-primary/20 text-primary px-3 py-1 rounded-full border border-primary/50">Admin Beta</span>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-surface p-4 rounded-xl border border-secondary flex items-center gap-4">
              <div className="p-3 bg-blue-500/10 text-blue-500 rounded-lg"><Package size={24} /></div>
              <div>
                  <p className="text-muted text-sm">إجمالي المنتجات</p>
                  <p className="text-2xl font-bold">{products.length}</p>
              </div>
          </div>
          <div className="bg-surface p-4 rounded-xl border border-secondary flex items-center gap-4">
              <div className="p-3 bg-red-500/10 text-red-500 rounded-lg"><AlertTriangle size={24} /></div>
              <div>
                  <p className="text-muted text-sm">تنبيهات المخزون</p>
                  <p className="text-2xl font-bold">{products.filter(p => p.stock < 5).length}</p>
              </div>
          </div>
          <div className="bg-surface p-4 rounded-xl border border-secondary flex items-center gap-4">
              <div className="p-3 bg-green-500/10 text-green-500 rounded-lg"><TrendingUp size={24} /></div>
              <div>
                  <p className="text-muted text-sm">إجمالي المبيعات (تجريبي)</p>
                  <p className="text-2xl font-bold">12,450 ج.م</p>
              </div>
          </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-surface rounded-xl border border-secondary overflow-hidden">
          <div className="p-4 border-b border-secondary">
              <h3 className="font-bold">إدارة المخزون</h3>
          </div>
          <div className="overflow-x-auto">
              <table className="w-full text-sm text-right">
                  <thead className="bg-black/20 text-muted">
                      <tr>
                          <th className="p-4">المنتج</th>
                          <th className="p-4">الفئة</th>
                          <th className="p-4">السعر</th>
                          <th className="p-4">المخزون الحالي</th>
                          <th className="p-4">الحالة</th>
                      </tr>
                  </thead>
                  <tbody>
                      {products.map(product => (
                          <tr key={product.id} className="border-b border-secondary last:border-0 hover:bg-white/5">
                              <td className="p-4 flex items-center gap-3">
                                  <img src={product.images[0]} className="w-10 h-10 rounded object-cover" />
                                  <span className="font-medium">{product.name}</span>
                              </td>
                              <td className="p-4 text-muted">{product.category}</td>
                              <td className="p-4">{product.price} ج.م</td>
                              <td className="p-4">
                                  <span className={product.stock < 5 ? 'text-red-500 font-bold' : ''}>
                                      {product.stock}
                                  </span>
                              </td>
                              <td className="p-4">
                                  {product.stock < 5 ? (
                                      <span className="flex items-center gap-1 text-red-500 text-xs bg-red-500/10 px-2 py-1 rounded w-fit">
                                          <AlertTriangle size={12} /> مخزون منخفض
                                      </span>
                                  ) : (
                                      <span className="text-green-500 text-xs bg-green-500/10 px-2 py-1 rounded w-fit">
                                          متوفر
                                      </span>
                                  )}
                              </td>
                          </tr>
                      ))}
                  </tbody>
              </table>
          </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
