
import React, { useState } from 'react';
import { MessageSquare, X, Send } from 'lucide-react';

interface ChatWidgetProps {
  isOpen: boolean;
  onToggle: () => void;
}

const ChatWidget: React.FC<ChatWidgetProps> = ({ isOpen, onToggle }) => {
  const [messages, setMessages] = useState([
      { id: 1, text: 'مرحباً! 👋 كيف يمكنني مساعدتك في طلبك اليوم؟', sender: 'support' }
  ]);
  const [inputValue, setInputValue] = useState('');

  const handleSend = () => {
      if (!inputValue.trim()) return;
      setMessages([...messages, { id: Date.now(), text: inputValue, sender: 'user' }]);
      setInputValue('');
      
      // Auto reply simulation
      setTimeout(() => {
          setMessages(prev => [...prev, { id: Date.now() + 1, text: 'شكراً لتواصلك معنا. سيقوم أحد ممثلي خدمة العملاء بالرد عليك قريباً.', sender: 'support' }]);
      }, 1000);
  };

  return (
    <>
      {/* Floating Button (Desktop Only) */}
      <button 
        onClick={onToggle}
        className={`hidden md:flex fixed left-4 bottom-8 z-40 p-4 rounded-full shadow-lg transition-all duration-300 hover:scale-110 ${isOpen ? 'bg-secondary text-text' : 'bg-primary text-white'}`}
      >
        {isOpen ? <X size={24} /> : <MessageSquare size={24} />}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed left-0 bottom-14 md:left-4 md:bottom-24 z-40 w-full md:w-[350px] h-[60vh] md:h-[450px] bg-surface md:border border-secondary md:rounded-2xl rounded-t-2xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-5">
            {/* Header */}
            <div className="bg-primary p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-white">
                        <MessageSquare size={20} />
                    </div>
                    <div>
                        <h3 className="font-bold text-white">خدمة العملاء</h3>
                        <p className="text-xs text-white/80">نرد عادة خلال دقائق</p>
                    </div>
                </div>
                {/* Close button for mobile */}
                <button onClick={onToggle} className="md:hidden text-white/80 hover:text-white">
                    <X size={24} />
                </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-background">
                {messages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-start' : 'justify-end'}`}>
                        <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${msg.sender === 'user' ? 'bg-secondary text-white rounded-tr-none' : 'bg-primary text-white rounded-tl-none'}`}>
                            {msg.text}
                        </div>
                    </div>
                ))}
            </div>

            {/* Input */}
            <div className="p-3 bg-surface border-t border-secondary flex gap-2">
                <input 
                    type="text" 
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="اكتب استفسارك هنا..."
                    className="flex-1 bg-secondary text-text text-sm px-3 py-2 rounded-full focus:outline-none focus:ring-1 focus:ring-primary"
                />
                <button onClick={handleSend} className="p-2 bg-primary rounded-full text-white hover:bg-blue-600 transition">
                    <Send size={18} className="-rotate-90 md:rotate-0" />
                </button>
            </div>
        </div>
      )}
    </>
  );
};

export default ChatWidget;
