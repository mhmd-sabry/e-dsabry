import React, { useState } from 'react';
import { Heart, MessageCircle, ShoppingBag, ChevronLeft, ChevronRight, Share2 } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onOpenDetails: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onLike: (id: string) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onOpenDetails, onAddToCart, onLike }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % product.images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
  };

  return (
    <div className="bg-surface rounded-[32px] border border-secondary/60 overflow-hidden flex flex-col h-full group relative shadow-sm">
      
      {/* Image Container */}
      <div 
        className="relative w-full aspect-square bg-surface overflow-hidden cursor-pointer"
        onClick={() => onOpenDetails(product)}
      >
        <img 
          src={product.images[currentImageIndex]} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        
        {/* Overlay Header */}
        <div className="absolute top-3 left-3 right-3 flex justify-between items-start z-10 pointer-events-none">
           {/* Brand Badge */}
            <div className="bg-black/30 backdrop-blur-md text-white text-[10px] px-2 py-1 rounded-full flex items-center gap-1 border border-white/10">
                 <div className="w-2 h-2 rounded-full bg-primary"></div>
                 <span className="font-medium">Dsabry</span>
            </div>
            
             {/* Stock Badge */}
             {product.stock < 5 && (
                <div className="bg-red-600/90 backdrop-blur-sm text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-lg animate-pulse">
                    {product.stock} قطع
                </div>
            )}
        </div>

        {/* Navigation Arrows (Only show if multiple images) */}
        {product.images.length > 1 && (
            <>
                <button 
                    onClick={nextImage}
                    className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/40 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10"
                >
                    <ChevronLeft size={16} />
                </button>
                <button 
                    onClick={prevImage}
                    className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/40 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10"
                >
                    <ChevronRight size={16} />
                </button>
                
                {/* Dots */}
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1 z-10">
                    {product.images.map((_, idx) => (
                        <div 
                            key={idx} 
                            className={`w-1 h-1 rounded-full transition-colors ${idx === currentImageIndex ? 'bg-white' : 'bg-white/40'}`}
                        />
                    ))}
                </div>
            </>
        )}
      </div>

      {/* Content & Actions */}
      <div className="p-3 flex flex-col gap-2 flex-1 justify-between bg-gradient-to-b from-surface to-background">
         <div>
             <div className="flex justify-between items-start">
                 <h3 className="font-bold text-sm text-text line-clamp-1 flex-1 ml-2">{product.name}</h3>
             </div>
             <p className="text-muted text-[10px] line-clamp-1 mb-1">{product.category}</p>
             <p className="text-primary font-bold text-base font-sans">{product.price} <span className="text-[10px] text-muted">ج.م</span></p>
         </div>

         {/* Action Buttons Row */}
         <div className="flex items-center gap-2 mt-1">
             <button 
                onClick={(e) => {
                    e.stopPropagation();
                    onAddToCart(product);
                }}
                className="flex-1 bg-secondary hover:bg-white hover:text-black transition text-xs font-bold py-2 rounded-xl flex items-center justify-center gap-1 active:scale-95"
            >
                <ShoppingBag size={14} />
                شراء
             </button>
             
             <button 
                onClick={(e) => {
                    e.stopPropagation();
                    onLike(product.id);
                }}
                className={`p-2 rounded-xl border border-secondary transition active:scale-90 ${product.isLiked ? 'bg-red-500/10 border-red-500/50' : 'hover:bg-secondary'}`}
             >
                <Heart size={16} className={product.isLiked ? "fill-red-500 text-red-500" : "text-text"} />
             </button>
         </div>
      </div>
    </div>
  );
};

export default ProductCard;