import React from 'react';
import { Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { Story } from '../types';

interface StoryRailProps {
  stories: Story[];
}

const StoryRail: React.FC<StoryRailProps> = ({ stories }) => {
  return (
    <div className="w-full border-b border-secondary bg-background py-5">
      <div className="flex gap-4 overflow-x-auto px-4 no-scrollbar items-center">
        {/* Your Story (Add) */}
        <motion.div 
            className="flex flex-col items-center gap-2 cursor-pointer flex-shrink-0 relative group"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
        >
          <div className="relative w-[74px] h-[74px] flex items-center justify-center">
             {/* Dashed Border Ring */}
             <motion.div 
                className="absolute inset-0 rounded-full border-2 border-dashed border-secondary group-hover:border-primary transition-colors duration-300" 
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
             />
             
             {/* Avatar Container */}
             <div className="w-[64px] h-[64px] rounded-full overflow-hidden bg-surface relative z-10">
               <img 
                 src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop" 
                 alt="Your Story" 
                 className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
               />
               <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
             </div>

             {/* Plus Badge */}
             <motion.div 
               className="absolute bottom-0 right-0 translate-x-1 -translate-y-1 bg-primary text-white rounded-full p-1 border-[3px] border-background shadow-sm z-20"
               animate={{ scale: [1, 1.2, 1] }}
               transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
             >
               <Plus size={14} strokeWidth={3} />
             </motion.div>
          </div>
          <span className="text-xs text-text font-medium mt-1">قصتي</span>
        </motion.div>

        {/* Other Stories */}
        {stories.map((story) => (
          <motion.div 
            key={story.id} 
            className="flex flex-col items-center gap-2 cursor-pointer flex-shrink-0"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <motion.div 
                className={`relative w-[74px] h-[74px] rounded-full p-[3px] flex items-center justify-center ${
                    story.hasUnseen 
                    ? 'bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600' 
                    : 'border border-secondary'
                }`}
                animate={story.hasUnseen ? {
                    scale: [1, 1.02, 1],
                } : {}}
                transition={story.hasUnseen ? {
                    duration: 2, 
                    repeat: Infinity, 
                    ease: "easeInOut" 
                } : {}}
            >
              <div className="bg-background rounded-full p-[3px] w-full h-full border-2 border-background overflow-hidden relative">
                <img 
                  src={story.avatar} 
                  alt={story.username} 
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
            </motion.div>
            <span className={`text-xs truncate w-20 text-center font-medium ${story.hasUnseen ? 'text-white' : 'text-muted'}`}>
                {story.username}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default StoryRail;