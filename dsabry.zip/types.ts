
export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  images: string[];
  category: string;
  stock: number;
  likes: number;
  comments: number;
  isLiked?: boolean;
}

export interface Story {
  id: string;
  username: string;
  avatar: string;
  hasUnseen: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}
