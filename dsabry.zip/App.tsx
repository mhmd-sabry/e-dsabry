
import React, { useState, useEffect } from 'react';
import { Home, Search, ShoppingBag, User, LayoutDashboard, PlusSquare, Menu, Plus, Minus, Trash2, Heart, MessageCircle } from 'lucide-react';
import StoryRail from './components/StoryRail';
import ProductCard from './components/ProductCard';
import ProductModal from './components/ProductModal';
import ChatWidget from './components/ChatWidget';
import AdminDashboard from './components/AdminDashboard';
import PromoCarousel from './components/PromoCarousel';
import { Product, Story, CartItem } from './types';

// Mock Data
const MOCK_STORIES: Story[] = [
  { id: '1', username: 'dsabry_fashion', avatar: 'https://images.unsplash.com/photo-1529139574466-a302d2052505?w=100&h=100&fit=crop', hasUnseen: true },
  { id: '2', username: 'tech_hub', avatar: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=100&h=100&fit=crop', hasUnseen: true },
  { id: '3', username: 'home_decor', avatar: 'https://images.unsplash.com/photo-1484101403633-562f891dc89a?w=100&h=100&fit=crop', hasUnseen: false },
  { id: '4', username: 'gifts_eg', avatar: 'https://images.unsplash.com/photo-1513201099705-a9746e1e201f?w=100&h=100&fit=crop', hasUnseen: true },
];

const MOCK_PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'ساعة ذكية Ultra Pro Max',
    price: 2500,
    description: 'أحدث ساعة ذكية مع شاشة AMOLED وقياس نبضات القلب ومقاومة للماء. تأتي مع 3 أحزمة إضافية.',
    category: 'إلكترونيات',
    stock: 12,
    likes: 1240,
    comments: 45,
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=600&h=600&fit=crop'
    ]
  },
  {
    id: 'p2',
    name: 'سنيكرز رياضي مريح',
    price: 850,
    description: 'حذاء رياضي مريح جداً للمشي والجري، تصميم عصري يناسب جميع الأذواق.',
    category: 'موضة',
    stock: 3, // Low stock for demo
    likes: 856,
    comments: 22,
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=600&h=600&fit=crop'
    ]
  },
  {
    id: 'p3',
    name: 'سماعة رأس عازلة للضوضاء',
    price: 3200,
    description: 'تجربة صوتية لا مثيل لها مع عزل ضوضاء نشط وبطارية تدوم 30 ساعة.',
    category: 'إلكترونيات',
    stock: 20,
    likes: 2100,
    comments: 103,
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&h=600&fit=crop'
    ]
  },
  {
    id: 'p4',
    name: 'حقيبة ظهر جلدية',
    price: 1200,
    description: 'حقيبة ظهر مصنوعة من الجلد الطبيعي، مثالية للعمل والسفر.',
    category: 'إكسسوارات',
    stock: 8,
    likes: 540,
    comments: 12,
    images: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&h=600&fit=crop'
    ]
  }
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'home' | 'admin' | 'cart'>('home');
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isChatOpen, setIsChatOpen] = useState(false);

  // Handlers
  const handleLike = (id: string) => {
    setProducts(prev => prev.map(p => 
      p.id === id ? { ...p, likes: p.isLiked ? p.likes - 1 : p.likes + 1, isLiked: !p.isLiked } : p
    ));
  };

  const handleAddToCart = (product: Product) => {
    if (product.stock <= 0) return;
    
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    // Decrement stock in products list
    setProducts(prev => prev.map(p => p.id === product.id ? { ...p, stock: Math.max(0, p.stock - 1) } : p));
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    // Find current stock info
    const currentProduct = products.find(p => p.id === productId);

    if (delta > 0) {
        // Increment
        if (currentProduct && currentProduct.stock > 0) {
            setCart(prev => prev.map(item => item.id === productId ? { ...item, quantity: item.quantity + 1 } : item));
            setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: p.stock - 1 } : p));
        }
    } else {
        // Decrement
        const cartItem = cart.find(item => item.id === productId);
        if (cartItem) {
            if (cartItem.quantity === 1 && delta === -1) {
                // Remove item completely
                setCart(prev => prev.filter(item => item.id !== productId));
            } else {
                setCart(prev => prev.map(item => item.id === productId ? { ...item, quantity: item.quantity - 1 } : item));
            }
            // Return stock to product list
            setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: p.stock + 1 } : p));
        }
    }
  };

  return (
    <div className="flex flex-col h-screen bg-black text-text font-sans">
      
      {/* Top Navbar */}
      <nav className="h-14 border-b border-secondary flex items-center justify-between px-4 sticky top-0 bg-background/90 backdrop-blur-md z-30">
        <div className="flex items-center gap-2">
           <span className="font-bold text-xl tracking-tighter italic font-serif">Dsabry</span>
           {activeTab === 'admin' && <span className="text-xs bg-red-600 text-white px-2 rounded-full">Admin</span>}
        </div>
        
        <div className="flex items-center gap-4">
           {activeTab === 'home' && (
              <button 
                onClick={() => setActiveTab('admin')}
                className="text-xs md:text-sm bg-secondary px-3 py-1.5 rounded-lg hover:bg-secondary/80 transition"
              >
                لوحة التاجر
              </button>
           )}
           <div className="relative cursor-pointer" onClick={() => setActiveTab('cart')}>
             <ShoppingBag size={24} />
             {cart.length > 0 && (
               <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full">
                 {cart.reduce((a, b) => a + b.quantity, 0)}
               </span>
             )}
           </div>
           {/* Desktop Messages Icon */}
           <button 
                onClick={() => setIsChatOpen(prev => !prev)}
                className="hidden md:block relative"
            >
               <MessageCircle size={24} />
           </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto no-scrollbar pb-16 md:pb-0 md:flex md:flex-row md:justify-center">
        
        {activeTab === 'home' && (
           <div className="w-full md:max-w-[470px] md:border-x md:border-secondary">
             <StoryRail stories={MOCK_STORIES} />
             
             {/* Promotional Carousel */}
             <PromoCarousel />
             
             {/* 2-Column Grid Layout */}
             <div className="grid grid-cols-2 gap-3 px-3 pb-24 pt-2">
               {products.map(product => (
                 <ProductCard 
                    key={product.id} 
                    product={product} 
                    onOpenDetails={setSelectedProduct}
                    onAddToCart={handleAddToCart}
                    onLike={handleLike}
                 />
               ))}
             </div>
           </div>
        )}

        {activeTab === 'admin' && (
            <AdminDashboard products={products} />
        )}

        {activeTab === 'cart' && (
            <div className="p-4 w-full md:max-w-2xl mx-auto">
                <h2 className="text-2xl font-bold mb-6">سلة التسوق</h2>
                {cart.length === 0 ? (
                    <div className="text-center text-muted py-12">
                        <ShoppingBag size={48} className="mx-auto mb-4 opacity-50" />
                        <p>السلة فارغة حالياً</p>
                        <button onClick={() => setActiveTab('home')} className="mt-4 text-primary">تصفح المنتجات</button>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {cart.map(item => (
                            <div key={item.id} className="flex gap-4 bg-surface p-4 rounded-xl border border-secondary">
                                <img src={item.images[0]} className="w-20 h-20 rounded-lg object-cover" />
                                <div className="flex-1 flex flex-col justify-between">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <h3 className="font-semibold">{item.name}</h3>
                                            <p className="text-primary font-bold">{item.price} ج.م</p>
                                        </div>
                                        <button 
                                            onClick={() => handleUpdateQuantity(item.id, -item.quantity)} // Remove all
                                            className="text-muted hover:text-red-500 transition"
                                        >
                                            <Trash2 size={18} />
                                        </button>
                                    </div>
                                    
                                    <div className="flex items-center gap-3 mt-3 bg-secondary/30 w-fit rounded-lg p-1 border border-secondary">
                                        <button 
                                            onClick={() => handleUpdateQuantity(item.id, -1)}
                                            className="p-1 hover:bg-white/10 rounded-md transition text-text/80 hover:text-red-400"
                                        >
                                            <Minus size={16} />
                                        </button>
                                        <span className="text-sm font-bold w-6 text-center">{item.quantity}</span>
                                        <button 
                                            onClick={() => handleUpdateQuantity(item.id, 1)}
                                            className={`p-1 hover:bg-white/10 rounded-md transition ${products.find(p => p.id === item.id)?.stock === 0 ? 'opacity-30 cursor-not-allowed' : 'text-text/80 hover:text-green-400'}`}
                                            disabled={products.find(p => p.id === item.id)?.stock === 0}
                                        >
                                            <Plus size={16} />
                                        </button>
                                    </div>
                                    <div className="mt-1 text-xs text-muted">
                                        {products.find(p => p.id === item.id)?.stock === 0 ? 'نفذت الكمية الإضافية' : `متبقي ${products.find(p => p.id === item.id)?.stock}`}
                                    </div>
                                </div>
                            </div>
                        ))}
                        <div className="pt-4 border-t border-secondary mt-8">
                            <div className="flex justify-between text-xl font-bold mb-4">
                                <span>الإجمالي</span>
                                <span>{cart.reduce((total, item) => total + (item.price * item.quantity), 0)} ج.م</span>
                            </div>
                            <button className="w-full bg-primary hover:bg-blue-600 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-900/20">
                                متابعة الدفع (Paymob)
                            </button>
                        </div>
                    </div>
                )}
            </div>
        )}

      </main>

      {/* Bottom Navigation (Mobile) - Instagram Style */}
      <div className="md:hidden fixed bottom-0 w-full h-14 bg-surface border-t border-secondary flex items-center justify-around z-30 px-2">
         {/* Home */}
         <button 
            onClick={() => setActiveTab('home')} 
            className="p-2 transition active:scale-95"
         >
             <Home size={26} className={activeTab === 'home' ? 'text-white fill-white' : 'text-muted'} />
         </button>
         
         {/* Search */}
         <button className="p-2 transition active:scale-95 text-muted hover:text-white">
            <Search size={26} />
         </button>
         
         {/* Messages (Chat Toggle) */}
         <button 
            onClick={() => setIsChatOpen(prev => !prev)}
            className={`p-2 transition active:scale-95 ${isChatOpen ? 'text-white fill-current' : 'text-muted hover:text-white'}`}
         >
            <MessageCircle size={26} />
         </button>
         
         {/* Notifications / Favorites */}
         <button className="p-2 transition active:scale-95 text-muted hover:text-white">
            <Heart size={26} />
         </button>
         
         {/* Profile (Mini Avatar) */}
         <button className="p-2 transition active:scale-95">
             <div className="w-6 h-6 rounded-full overflow-hidden border border-muted">
                 <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop" className="w-full h-full object-cover" />
             </div>
         </button>
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductModal 
            product={selectedProduct} 
            onClose={() => setSelectedProduct(null)} 
            onAddToCart={handleAddToCart}
        />
      )}

      {/* Live Chat (Controlled by App state) */}
      <ChatWidget isOpen={isChatOpen} onToggle={() => setIsChatOpen(!isChatOpen)} />
    </div>
  );
};

export default App;
